import os


# функция ввода целого числа с обработкой ошибки ввода
def input_d(string):
    x = None
    while x == None:
        try:
            x = int(input(string))
        except ValueError:
            print('Ошибка ввода данных!')
    return x


# функция чтения данных из файла в список строк с обработкой ошибки, если файла нет
def readfile(name):
    data = []
    try:
        f = open(name)
        data = f.readlines()
        f.close()
    except FileNotFoundError:
        print('Нет такой записи, но Вы можете ее создать.')
    return data


# функция записи информации в файл
def writefile(name, regime):
    f = open(name, regime)
    if regime == 'a':
        f.write('\n')
    param = input_d('Задайте количество параметров: ')
    for i in range(param):
        f.write(input('Параметр ' + str(i + 1) + ': '))
        f.write('\t')
        f.write(input('Значение: '))
        f.write('\n')
    comment = input('Комментарий (описание): ')
    f.write(comment)
    f.close()


# функция создания новой записи - текстового файла данных
def create_note():
    print('Создание записи...')
    catalog = input('Задайте рубрику: ')
    try:
        os.mkdir(catalog.upper())
    except FileExistsError:
        pass
    name_note = input('Введите название: ')
    writefile(catalog.upper() + '/' + name_note.upper() + '.txt', 'w')
    print('Запись сохранена!')
    

# функция нахождения записи и ее вывода на экран
def find_note():
    print('Поиск записи...')
    catalog = input('Задайте рубрику: ')
    name_note = input('Введите название: ')
    print()
    data = readfile(catalog.upper() + '/' + name_note.upper() + '.txt')
    if data != []:
        print('ИНФОРМАЦИЯ: ' + catalog.upper() + ' / ' + name_note.upper() + ':')
        print()
        for row in data:
            print(row)
        return catalog.upper() + '/' + name_note.upper() + '.txt'
    else:
        return None


# функция изменения (переписывания) записи
def modify_note(path):
    writefile(path, 'w')
    print('Запись переписана!')


# функция добавления информации в существующую запись
def add_note(path):
    writefile(path, 'a')
    print('Информация добавлена!')


# основная программа
print('Это универсальный блокнот. Вы можете хранить записи произвольного количества \
параметров и один комментарий (описание).')
print('Это могут быть рецепты, списки покупок, данные артериального давления и т.п.')
print()
vyhod = '0'
while vyhod == '0':
    create = input('CОЗДАТЬ новую запись - 0, НАЙТИ запись - любой иной символ: ')
    print()
    if create == '0':
        create_note()
    else:
        path = find_note()
        if path != None:
            print()
            action = input('ПЕРЕПИСАТЬ - 0, ДОПОЛНИТЬ - 1, УДАЛИТЬ - 2, ЗАКРЫТЬ - любой иной символ: ')
            print()
            if action == '0':
                modify_note(path)
            if action == '1':
                add_note(path)
            if action == '2':
                os.remove(path)          
    print()
    vyhod = input('Продолжить работу с блокнотом: Да - 0, Нет - любой иной символ? ')
    print()
